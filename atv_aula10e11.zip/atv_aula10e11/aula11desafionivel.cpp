#include <queue>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

// ------------------------------------------------------------
// PRONTA: o no com vetor de filhos
// ------------------------------------------------------------
struct No {
    string valor;
    vector<No*> filhos;

    No(string novoValor) {
        valor = novoValor;
    }
};

// ------------------------------------------------------------
// PRONTA: cria um filho e devolve o endereco dele
// ------------------------------------------------------------
No* criarFilho(No* pai, string valor) {
    No* filho = new No(valor);
    pai->filhos.push_back(filho);
    return filho;
}

// ------------------------------------------------------------
// PRONTA: monta a arvore de teste
// ------------------------------------------------------------
No* montarArvore() {
    No* raiz = new No("projeto");
    No* src = criarFilho(raiz, "src");
    criarFilho(src, "main.cpp");
    No* estruturas = criarFilho(src, "estruturas");
    criarFilho(estruturas, "lista.cpp");
    criarFilho(estruturas, "pilha.cpp");
    No* docs = criarFilho(raiz, "docs");
    criarFilho(docs, "manual.pdf");
    criarFilho(raiz, "README.md");
    return raiz;
}

// ------------------------------------------------------------
// Escreva a funcao percorrerPorNivel.
// ------------------------------------------------------------
void percorrerPorNivel(No* raiz) {
    if (raiz == nullptr) {
        return;
    }

    queue<No*> fila;
    fila.push(raiz);

    while (!fila.empty()) {
        No* atual = fila.front();
        cout << atual->valor << " ";
        fila.pop();
        for (No* filho : atual->filhos) {
            fila.push(filho);
        }
    }
}

int main() {
    No* raiz = montarArvore();
    percorrerPorNivel(raiz);
    cout << endl;
    return 0;
}
